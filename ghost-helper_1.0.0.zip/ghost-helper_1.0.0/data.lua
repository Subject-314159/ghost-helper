require("prototypes/shortcut")
require("prototypes/sprite")
require("prototypes/style")
