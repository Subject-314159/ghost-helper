data:extend({{
    type = "sprite",
    name = "icon-ghost",
    filename = "__ghost-helper__/graphics/icons/ghost.png",
    size = 64
}, {
    type = "sprite",
    name = "icon-storage",
    filename = "__ghost-helper__/graphics/icons/storage.png",
    size = 64
}, {
    type = "sprite",
    name = "icon-craft",
    filename = "__ghost-helper__/graphics/icons/craft.png",
    size = 64
}})
