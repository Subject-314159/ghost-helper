data:extend({{
    type = "custom-input",
    name = "gh_toggle-gui",
    key_sequence = "ALT + G",
    action = "lua",
    order = "a"
}, {
    type = "shortcut",
    name = "gh_toggle-gui",
    action = "lua",
    icon = {
        filename = "__ghost-helper__/graphics/icons/ghost-black.png",
        size = 32
    }
}})
